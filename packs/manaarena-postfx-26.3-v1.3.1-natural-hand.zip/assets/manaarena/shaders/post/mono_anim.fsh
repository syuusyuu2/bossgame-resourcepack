#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;
layout(std140) uniform NoiseConfig { vec4 Grain; };
void main(){vec4 scene=texture(InSampler,texCoord);vec2 p=texCoord*2.0-1.0;float edge=smoothstep(0.25,0.95,max(abs(p.x),abs(p.y)));float noise=fract(sin(dot(floor(gl_FragCoord.xy)+vec2(Grain.x*211.37,Grain.x*97.13),vec2(12.9898,78.233)))*43758.5453)-0.5;float light=dot(scene.rgb,vec3(0.2126,0.7152,0.0722));float grey=clamp(light*(Grain.y-edge*Grain.w)+noise*(Grain.z+edge*0.08),0.0,1.0);fragColor=vec4(vec3(grey),scene.a);}
