#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
layout(std140) uniform ShakeConfig {
    vec4 Offset; // fixed preset UV offset; maximum abs(x)=0.006, abs(y)=0.0015
};
void main(){
    // Slight overscan hides exposed edges. No brightness, time, camera or aim modification.
    vec2 uv = (texCoord - vec2(0.5)) * 0.984 + vec2(0.5) + Offset.xy;
    fragColor = texture(InSampler, clamp(uv, vec2(0.0), vec2(1.0)));
}
