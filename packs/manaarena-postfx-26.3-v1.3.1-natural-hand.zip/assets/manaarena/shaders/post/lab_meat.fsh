#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
layout(std140) uniform EdgeConfig {
    vec4 TintOpacity; // x: fine peripheral branch darkness; y: peripheral desaturation; a: base darkness
    vec4 Shape;       // x/y: inner/outer extent of the peripheral mask
};
void main(){
    vec4 scene = texture(InSampler, texCoord);
    vec2 p = texCoord * 2.0 - 1.0;
    float edge = smoothstep(Shape.x, Shape.y, max(abs(p.x), abs(p.y)));
    // Preserve already-rendered dark-red torso/outline pixels and other clear red signals.
    float redSignal = smoothstep(0.02, 0.07, scene.r - max(scene.g, scene.b));
    float amount = edge * (1.0 - redSignal);
    float grey = dot(scene.rgb, vec3(0.2126, 0.7152, 0.0722));
    vec3 muted = mix(scene.rgb, vec3(grey) * vec3(0.80, 0.84, 0.88), TintOpacity.y * amount);
    float branches = pow(0.5 + 0.5 * sin(atan(p.y + 0.000001,p.x + 0.000001) * 13.0 + length(p) * 7.0), 12.0);
    // Static peripheral pattern only: no noise, temporal modulation, glow expansion or UV movement.
    fragColor = vec4(muted * (1.0 - amount * (TintOpacity.a + TintOpacity.x * branches)), scene.a);
}
