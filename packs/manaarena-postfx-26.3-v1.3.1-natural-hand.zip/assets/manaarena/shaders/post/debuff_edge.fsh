#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
layout(std140) uniform EdgeConfig {
    vec4 TintOpacity;
    vec4 Shape; // x/y: inner/outer radius of the thin rim
};
void main(){
    vec4 scene=texture(InSampler,texCoord);
    vec2 p=texCoord*2.0-1.0;
    float rim=smoothstep(Shape.x,Shape.y,max(abs(p.x),abs(p.y)));
    // Existing red markers stay red even when they reach the peripheral rim.
    float redSignal=smoothstep(0.02,0.07,scene.r-max(scene.g,scene.b));
    fragColor=vec4(mix(scene.rgb,TintOpacity.rgb,rim*TintOpacity.a*(1.0-redSignal)),scene.a);
}
