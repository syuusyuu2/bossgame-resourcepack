#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;
layout(std140) uniform EdgeConfig { vec4 TintOpacity; vec4 Shape; };
void main(){vec4 scene=texture(InSampler,texCoord);vec2 p=texCoord*2.0-1.0;float edge=smoothstep(0.2,0.95,max(abs(p.x),abs(p.y)));float noise=fract(sin(dot(floor(gl_FragCoord.xy)+vec2(Shape.x*211.37,Shape.x*97.13),vec2(12.9898,78.233)))*43758.5453)-0.5;vec3 hot=vec3(scene.r*1.1+scene.g*0.18,scene.g*0.20,scene.b*0.10);vec3 colour=mix(scene.rgb,hot,0.82);colour=mix(colour,TintOpacity.rgb*0.55,0.16+edge*TintOpacity.a);colour*=Shape.y-edge*Shape.w;colour+=noise*(Shape.z+edge*0.06)*vec3(1.0,0.28,0.20);fragColor=vec4(clamp(colour,0.0,1.0),scene.a);}
