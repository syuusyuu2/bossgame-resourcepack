#version 330
#extension GL_ARB_separate_shader_objects : require
uniform sampler2D InSampler;
layout(location=0) in vec2 texCoord;
layout(location=0) out vec4 fragColor;
layout(std140) uniform EdgeConfig { vec4 TintOpacity; vec4 Shape; };
void main(){vec4 scene=texture(InSampler,texCoord);fragColor=vec4(mix(scene.rgb,TintOpacity.rgb,TintOpacity.a),scene.a);}
