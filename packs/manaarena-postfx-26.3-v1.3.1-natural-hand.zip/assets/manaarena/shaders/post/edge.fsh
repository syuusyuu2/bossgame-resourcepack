#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
layout(std140) uniform EdgeConfig {
    vec4 TintOpacity;
    vec4 Shape; // x/y: screen direction; z: 0=perimeter, 1=direction, 2=spectrum, 3=mono+static grain
};
void main() {
    vec4 scene = texture(InSampler, texCoord);
    vec2 p = texCoord * 2.0 - 1.0;
    float edge = smoothstep(0.30, 0.95, max(abs(p.x), abs(p.y)));
    vec3 tint = TintOpacity.rgb;
    if (Shape.z > 0.5 && Shape.z < 1.5) {
        float alignment = dot(normalize(p + vec2(0.000001)), Shape.xy);
        edge *= smoothstep(0.45, 0.95, alignment);
    }
    if (Shape.z > 1.5 && Shape.z < 2.5) {
        float hue = atan(p.y, p.x) / 6.2831853;
        tint = 0.5 + 0.5 * cos(6.2831853 * (hue + vec3(0.0, 0.3333333, 0.6666667)));
    }
    if (Shape.z > 2.5) {
        float luminance = dot(scene.rgb, vec3(0.2126, 0.7152, 0.0722));
        // Fixed screen-space grain: no time input, temporal flicker or animated scan lines.
        float grain = fract(sin(dot(floor(gl_FragCoord.xy), vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
        float noiseAmplitude = mix(0.024, 0.090, edge);
        float grey = clamp(luminance * (1.0 - 0.16 * edge) + grain * noiseAmplitude, 0.0, 1.0);
        fragColor = vec4(vec3(grey), scene.a);
        return;
    }
    // Other modes leave the centre unchanged. None displaces the scene or oscillates.
    fragColor = vec4(mix(scene.rgb, tint, edge * TintOpacity.a), scene.a);
}
