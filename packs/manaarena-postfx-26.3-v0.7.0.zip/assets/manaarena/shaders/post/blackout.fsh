#version 330
uniform sampler2D InSampler;
in vec2 texCoord;
out vec4 fragColor;
void main(){vec4 scene=texture(InSampler,texCoord);fragColor=vec4(min(scene.rgb,vec3(0.0)),scene.a);}
